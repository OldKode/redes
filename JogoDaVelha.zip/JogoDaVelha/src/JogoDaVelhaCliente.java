import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
 
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.net.UnknownHostException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
 
/*Thread que recebe mensagens do socket*/
class ThreadEscuta extends Thread {
	Socket	 		s;
	JogoDaVelhaCliente 	t;
	ThreadEscuta(Socket socket, JogoDaVelhaCliente JogoDaVelhaCli) {
		s = socket;
		t = JogoDaVelhaCli;
	}
	
	public void run() {
		try {
			while (true) {
				//Aguarda a resposta
				InputStream istream = s.getInputStream();
				InputStreamReader reader = new InputStreamReader(istream); 
				BufferedReader br = new BufferedReader(reader);  
				String msg = br.readLine();
                                t.b[Integer.valueOf(msg)].setText("O");
				//t.setMsg(msg);                                
                                t.atualizaVez();
				t.validaVitoria();
                                
				//t.addStrTextArea(); 
				Thread.sleep(200);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

public class JogoDaVelhaCliente extends javax.swing.JFrame implements ActionListener{
        private 	Socket  	socket;
        private		OutputStream 	ostream;
        private		String		msg;    //msg precisa ser private para ser usada com invokeLater
    
        public JButton[] b = new JButton[9];
        private int pontoCli = 0, pontoServ = 0;
        private GridLayout game_layout; 
        private BorderLayout main_layout;
        private JLabel  labelPlacar = new JLabel("Cliente: " + pontoCli + "  Servidor:" + pontoServ);
        private int gameCounter = 0;
         
        private boolean jogando = false;
        
        public JogoDaVelhaCliente(Socket s) {        
            
            //Instancia socket
            socket = s;
            
            //Configura botoes
            for (int i=0; i < 9; i++){
                b[i] = new javax.swing.JButton();                       
                b[i].setText("");
                b[i].addActionListener(this);
            }
 
            //Define o layout do jogo da velha
            JPanel panel_game = new JPanel();
            game_layout = new GridLayout( 3, 3 );
            panel_game.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            panel_game.setLayout(game_layout);
            //Adiciona os botoes ao layout do jogo
            for (int i=0; i < 9; i++){
                panel_game.add(b[i],0);
            }
             
            //Define o layou do score
            JPanel panel_score = new JPanel();  
            panel_score.add(labelPlacar);
             
             
            //Define o layout principal
            //Jogo da velha no centro, placar ao lado direito           
            main_layout = new BorderLayout();
            getContentPane().setLayout(main_layout);
            add(panel_game, BorderLayout.CENTER);
            add(panel_score, BorderLayout.EAST);
        }         
                
        public void actionPerformed(ActionEvent e) {
            if (this.jogando)
            for (int i=0; i < 9; i++){
                if (e.getSource() == b[i]) {
                    if(!b[i].getText().isEmpty())
                        return;
                    //System.out.println("Botao " + i + " pressionado");
                    //Envia Mensagem via socket		    		
                    PrintWriter pw = new PrintWriter(ostream, true); 
                    pw.println(i);                        
                    b[i].setText("X");                    
                    this.atualizaVez(); 
                    this.validaVitoria();
                }
            }
        }           
        
        public void validaVitoria(){
            int tela[][] = {{0,0,0},{0,0,0},{0,0,0}}; //new int [3][3];
            
            int cont = 0;
            //monta tela em array de int
            for (int i=0; i < 3; i++){
                for (int j=0; j < 3; j++){                    
                    if(b[cont].getText() == "X")
                        tela[i][j] = 1;
                    if(b[cont].getText() == "O")
                        tela[i][j] = 2;
                    cont++;
                }
            }                        
            
            //Printa array de seleções
            /*
            for (int i=0; i < 3; i++){
                for (int j=0; j < 3; j++){
                        System.out.print(tela[i][j]);
                }
                System.out.println("");
            }
            System.out.println("------------------------------------");
            */
            //valida vitória
            if (validaCombinacao(tela,1))
                this.atualizaPonto(1);
            if (validaCombinacao(tela,2))
                this.atualizaPonto(2);     
            
            //valida empate
            boolean velha = true;
            //monta tela em array de int
            for (int i=0; i < 3; i++){
                for (int j=0; j < 3; j++){
                    if(tela[i][j] == 0)
                        velha = false;
                }
            }
            if (velha)                
                this.atualizaPonto(0);
        }
        
        public boolean validaCombinacao(int[][] tela, int comp){
            if (tela[0][0] == comp && tela[1][0] == comp && tela[2][0] == comp)
                return true;            
            if (tela[0][1] == comp && tela[1][1] == comp && tela[2][1] == comp)
                return true;            
            if (tela[0][2] == comp && tela[1][2] == comp && tela[2][2] == comp)
                return true;
                    
            
            if (tela[0][0] == comp && tela[0][1] == comp && tela[0][2] == comp)
                return true;            
            if (tela[1][0] == comp && tela[1][1] == comp && tela[1][2] == comp)
                return true;
            if (tela[2][0] == comp && tela[2][1] == comp && tela[2][2] == comp)
                return true;
                    
            if (tela[0][0] == comp && tela[1][1] == comp && tela[2][2] == comp)
                return true;
            if (tela[0][2] == comp && tela[1][1] == comp && tela[2][0] == comp)
                return true;
            
            return false;
        }
        
        public void atualizaVez(){
            if (this.jogando){
                this.jogando = false;                      
                this.setTitle("Cliente");
            }else{
                this.jogando = true;
                this.setTitle("Cliente - SUA VEZ!");
            }
        }
        
        public void init(){
            try {
                         ostream = socket.getOutputStream();
                 } catch (IOException e) {
                         System.out.println("Não conseguiu pegar outputstream");
                 }            
        }
              
        public void limpaBotoes(){
            for (int i=0; i < 9; i++){               
                b[i].setText("");                                             
            }
        }
        
        public void atualizaPonto(int comando){
            //comando:
            // 1 - vitoria do cliente
            // 2 - vitoria do servidor
            // 0 - deu velha
            
            if (comando == 1){
                this.pontoCli++;
                JOptionPane.showMessageDialog(null,"Cliente ganhou");
            }
            else if (comando == 2){
                this.pontoServ++;      
                JOptionPane.showMessageDialog(null,"Servidor ganhou");
            }else{
                JOptionPane.showMessageDialog(null,"Deu Velha");
            }
            
            this.limpaBotoes();
            
            this.labelPlacar.setText("Cliente: " + pontoCli + "  Servidor:" + pontoServ);
        }
        
        public static void main(String[] args) {
            //Cria o socket cliente, o jframe e a thread
            try{
                //Cria o socket cliente, o jframe e a thread
                String ipdoServidor = JOptionPane.showInputDialog("Informe o IP do servidor","localhost");
                String portadoServidor = JOptionPane.showInputDialog("Informe a porta do servidor","1234");

                
                Socket              socket = new Socket(ipdoServidor,Integer.valueOf(portadoServidor));                
                
                //Starta tela / Cria thread
                JogoDaVelhaCliente  jogo = new JogoDaVelhaCliente(socket);
                ThreadEscuta        tescuta = new ThreadEscuta(socket, jogo);
                
                //Configurando tela
                jogo.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
                jogo.setSize( 300, 200 ); // set frame size
                jogo.setVisible( true );
                jogo.setTitle("Cliente");
                jogo.init();                
                jogo.atualizaVez();
                
                tescuta.start();
            } catch (Exception e) {
			System.out.println("Falha ao conectar com servidor...");
            }  
        }    
}