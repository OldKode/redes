import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
 
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.net.UnknownHostException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
 
 /*Thread que recebe comando do socket*/
class ThreadEscutaServer extends Thread {
	Socket	 		s;
	JogoDaVelha      	t;
	ThreadEscutaServer(Socket socket, JogoDaVelha Jog) {
		s = socket;
		t = Jog;
	}
	
	public void run() {
		try {
			while (true) {
				//Aguarda a resposta
				InputStream istream = s.getInputStream();
				InputStreamReader reader = new InputStreamReader(istream); 
				BufferedReader br = new BufferedReader(reader);  
				String msg = br.readLine();
                                System.out.println(msg);
                                t.b[Integer.valueOf(msg)].setText("x");
                                //t;
				//t.setMsg(msg);
				
				//t.addStrTextArea(); 
				Thread.sleep(200);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
 
public class JogoDaVelha extends javax.swing.JFrame implements ActionListener{
        private 	Socket  	socket;
        private		OutputStream 	ostream;
        private		String		msg;    //msg precisa ser private para ser usada com invokeLater
    
        public JButton[] b = new JButton[9];
        private GridLayout game_layout; 
        private BorderLayout main_layout;
        private JLabel  labelPlacar = new JLabel("Cliente: 0  Servidor:0");
        private int gameCounter = 0;
         
        public JogoDaVelha(Socket s) {        
            
            //Instancia socket
            socket = s;
            
            //Configura botoes
            for (int i=0; i < 9; i++){
                b[i] = new javax.swing.JButton();                       
                b[i].setText("");
                b[i].addActionListener(this);
            }
 
            //Define o layout do jogo da velha
            JPanel panel_game = new JPanel();
            game_layout = new GridLayout( 3, 3 );
            panel_game.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            panel_game.setLayout(game_layout);
            //Adiciona os botoes ao layout do jogo
            for (int i=0; i < 9; i++){
                panel_game.add(b[i],0);
            }
             
            //Define o layou do score
            JPanel panel_score = new JPanel();  
            panel_score.add(labelPlacar);
             
             
            //Define o layout principal
            //Jogo da velha no centro, placar ao lado direito           
            main_layout = new BorderLayout();
            getContentPane().setLayout(main_layout);
            add(panel_game, BorderLayout.CENTER);
            add(panel_score, BorderLayout.EAST);
        }         
                
        public void actionPerformed(ActionEvent e) {
            int i ;
            for (i=0; i < 9; i++){
                if (e.getSource() == b[i]) {
                    //System.out.println("Botao " + i + " pressionado");       
                    //Envia Mensagem via socket		    		
                    PrintWriter pw = new PrintWriter(ostream, true); 
                    pw.println(i);
                    System.out.println(i);
                    //Limpa o campo de texto usando invokeLater
                    //assim nao tem perigo de conflitarmos com a 
                    //Thread do swing
                    SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                   //jTextField1.setText(null);
                            }
                    });
                }
            }
            
            
        }  
         
        public void init(){
           try {
                    ostream = socket.getOutputStream();
            } catch (IOException e) {
                    System.out.println("Não conseguiu pegar outputstream");
            }
        }
                     
        public static void main(String[] args) {
            //Cria o socket cliente, o jframe e a thread
            try{
                ServerSocket ss     = new ServerSocket(1234);
                JOptionPane.showMessageDialog(null, "Aguardando a conexão do programa cliente. IP do Servidor: localhost, Porta do Servidor: " + ss.getLocalPort(), null, JOptionPane.PLAIN_MESSAGE , null);
                Socket      socket  = ss.accept();

                //Starta tela / Cria thread
                JogoDaVelha jogo            = new JogoDaVelha(socket);
                ThreadEscutaServer tescuta  = new ThreadEscutaServer(socket, jogo);
                
                //Configurando tela
                jogo.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
                jogo.setSize( 300, 200 ); // set frame size
                jogo.setVisible( true );
                jogo.setTitle("Servidor");
                jogo.init();
                tescuta.start();
            } catch (Exception e) {
			System.out.println("Falha ao conectar com servidor...");
            }  
        }    
}