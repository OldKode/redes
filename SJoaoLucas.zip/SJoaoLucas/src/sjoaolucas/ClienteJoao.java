/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjoaolucas;

import java.net.*;
import java.io.*;
/**
 *
 * @author joao.lslima1
 */
public class ClienteJoao {
    public static void main (String [] args){       
        ///////////////////////////////////////////
        //Exercicio a executar.
        int exercicio = 4;
        //////////////////////////////////////////
        SocketTCP cliente = new SocketTCP();
        String nome;
        int porta;
        
        
        // Padrão
        nome = "localhost";
        porta = 4567;
        
        
        switch(exercicio){            
            case 1:
                if (cliente.ConectaTcp(nome, porta)){
                    System.out.println("Conectou.");
                }else{
                    System.out.println("Não conectou.");
                }
                break;
            case 2:
                for(porta = 4560; porta <= 4570; porta++){
                     if (cliente.ConectaTcp(nome, porta)){
                        System.out.println("Conectou na porta : " + porta);
                    }else{
                        System.out.println("Não conectou na porta : " + porta);
                    }
                }
                break;
            case 3:
                cliente.ConectaServer(nome, porta);
                cliente.enviaMensagem("Teste do jojão!!!!!! kek");
                cliente.enviaMensagem();
                
                break;
                
            case 4:
                nome = "www.sp.senac.br";
                porta = 80;
                
                cliente.ConectaServer(nome, porta);
                cliente.enviaComando("GET /jsp/default.jsp\r\n");
                
                
        }
    }
}
