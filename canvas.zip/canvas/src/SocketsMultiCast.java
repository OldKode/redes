
import java.net.*;
import java.io.*;
import javax.swing.JOptionPane;

public class SocketsMultiCast {
    private MulticastSocket working_socket;
    static final int MULTICAST_PORT = 4446;
    static final String MULTICAST_IP_ADDRESS = "230.0.0.1";
    InetAddress group = null;
    
    
    SocketsMultiCast() {
    	try {
    		working_socket = new MulticastSocket(MULTICAST_PORT);
    		group = InetAddress.getByName(MULTICAST_IP_ADDRESS);
    		working_socket.joinGroup(group);
    	} catch (Exception err) { 
	    		JOptionPane.showMessageDialog(null, err.getMessage(), null, JOptionPane.PLAIN_MESSAGE , null);
    	}
    }
    
    public void sendMsg(byte[] msg) {
        try {
       		InetAddress address = InetAddress.getByName(MULTICAST_IP_ADDRESS);
       		DatagramPacket packet = new DatagramPacket(msg, msg.length, address, MULTICAST_PORT);
       		working_socket.send(packet);
        } catch (Exception err) {
             JOptionPane.showMessageDialog(null, err.getMessage(), null, JOptionPane.PLAIN_MESSAGE , null);
        }
    }

    public byte[] recvMsg() {
        byte[] msg = new byte[100];
        try {
        	DatagramPacket packet = new DatagramPacket(msg, msg.length);
        	working_socket.receive(packet);
        	msg = packet.getData();
        } catch (Exception err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), null, JOptionPane.PLAIN_MESSAGE , null);
        }
        return msg;
    }        
 
   void close(){
        try {
        	working_socket.leaveGroup(group);
            working_socket.close();
        } catch (Exception err) {
                JOptionPane.showMessageDialog(null, err.getMessage(), null, JOptionPane.PLAIN_MESSAGE , null);
        }
    }
}



