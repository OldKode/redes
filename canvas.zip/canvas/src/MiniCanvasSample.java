
import java.awt.Color;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


/*Thread que recebe mensagens do socket*/
class ThreadEscuta extends Thread {

    MiniCanvasSample tela;
    SocketsMultiCast sock;

    ThreadEscuta(MiniCanvasSample talkGUI, SocketsMultiCast sockte) {
        tela = talkGUI;
        sock = sockte;
    }

    public void run() {
        try {
            while (true) {
                //Aguarda a resposta       
                //String msg = sock.recvMsg().getBytes();
                String msg = new String(sock.recvMsg()).trim();
                //System.out.println(msg);
                if (msg != null) {
                    String[] trat = msg.split(",");
                    tela.moveNome(trat[0], trat[1], trat[2]);
                }
                Thread.sleep(200);
            }
        } catch (Exception e) {
            System.out.println("asdsd " + e.getMessage());
        }
    }
}

public class MiniCanvasSample extends JPanel {

    private SocketsMultiCast socketMult;
    static private String username = "";
    static private int x = 0;
    static private int y = 0;
    static String[][] Nomes = new String[5][3];

    public MiniCanvasSample(SocketsMultiCast sock) {
        socketMult = sock;
        //Monitora eventos de teclado
        this.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                MoveObject(e);
            }
        });
    }

    void moveNome(String nome, String x, String y) {
        for (int lnFor = 0; lnFor < 5; lnFor++) {
            if ((Nomes[lnFor][0] == null) || Nomes[lnFor][0].isEmpty()) {
                Nomes[lnFor][0] = nome;
                Nomes[lnFor][1] = String.valueOf(x);
                Nomes[lnFor][2] = String.valueOf(y);
                break;
            } else if (Nomes[lnFor][0].compareTo(nome) == 0) {
                Nomes[lnFor][1] = String.valueOf(x);
                Nomes[lnFor][2] = String.valueOf(y);
                break;
            }
        }
        repaint();
    }

    //Atualizacao da tela com o nome do usuario na posicao x,y
    public void paint(Graphics g) {
        //Obtem o foco para obter eventos de teclado

        requestFocus();
        g.clearRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.black);

        //Desenha o nome do usuario
        for (int lnFor = 0; lnFor < 3; lnFor++) {
            if ((Nomes[lnFor][0] != null) && (!Nomes[lnFor][0].isEmpty())) {
                for (int indice = 0; indice < 3; indice++) {
                    if (Nomes[indice][1] == Nomes[lnFor][1] 
                     && Nomes[indice][2] == Nomes[lnFor][2] 
                     && Nomes[indice][0].compareTo(Nomes[lnFor][0]) != 0) {
                        g.setColor(Color.red);
                        break;
                    }else{
                        g.setColor(Color.black);
                    }                    
                }
                g.drawString(Nomes[lnFor][0], Integer.valueOf(Nomes[lnFor][1]), Integer.valueOf(Nomes[lnFor][2]));
            }
        }
    }

    //Controla acoes do teclado
    public void MoveObject(KeyEvent e) {
        int keyCode = e.getKeyCode();
        int offset = 5;
        switch (keyCode) {
            case KeyEvent.VK_UP:
                y = y - offset;
                break;
            case KeyEvent.VK_DOWN:
                y = y + offset;
                break;
            case KeyEvent.VK_LEFT:
                x = x - offset;
                break;
            case KeyEvent.VK_RIGHT:
                x = x + offset;
                break;
        }
        String msg = this.username + "," + x + "," + y;
        byte[] mens = new byte[1000];
        mens = msg.getBytes();
        this.socketMult.sendMsg(mens);
        //Redesenha com a nova posição
        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Mini Canvas Sample");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        SocketsMultiCast sock = new SocketsMultiCast();
        MiniCanvasSample mCanvas = new MiniCanvasSample(sock);
        ThreadEscuta tescuta = new ThreadEscuta(mCanvas, sock);
        tescuta.start();
        frame.add(mCanvas);
        frame.setSize(300, 200);
        //Nome do usuario gerado aleatoriamente
        Random rnd = new Random();
        username = Integer.toString(rnd.nextInt());
        //Posição inicial do texto
        x = 300 / 2;
        y = 200 / 2;
        frame.setVisible(true);
    }
}
