/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joao.lslima1
 */
import java.io.*;
import java.net.*;

public class ServerThread extends Thread {
	private Socket socket;
	
	public ServerThread ( Socket socket){

		this.socket = socket;
		start();
	
	}

	public void run(){
		try{
			int x, y;
			DataOutputStream o = new DataOutputStream(socket.getOutputStream());
			DataInputStream  i = new DataInputStream(socket.getInputStream());
			x = i.readInt();
			y = i.readInt();
			System.out.println("Servidor recebeu " + String.valueOf(x) + " e "
					+ String.valueOf(y) + " e vai enviar "
					+ String.valueOf( x + y )
			);
			o.writeInt(x+y);
			socket.close();
		}catch(EOFException ie){
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}
}