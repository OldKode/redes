/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joao.lslima1
 */
import java.io.*;
import java.net.*;

public class ServerThread extends Thread {
	private Socket socket;
        private Servidor pai;
	private	OutputStream 	ostream;
        private int id;
        private String nome;
        private OutputStream ostreamAux;
        
	public ServerThread ( Socket socket, Servidor serv, int id){
		this.socket = socket;
                this.pai = serv;
                this.id = id;
		start();
	}
        
        public void enviaMensagem(String msg) throws IOException{                               
            ostream = socket.getOutputStream();
            PrintWriter pw = new PrintWriter(ostream, true); 
            pw.println(msg);
        }
        
        public boolean validaNome(String nome){
            if(nome.compareTo(this.nome) == 0){
                return true;
            }
            return false;
        }
        
        public void fechaConexao(){
            pai.deletaThread(this);
        }

	public void run(){
                try{
                    if (this.nome == null){
                    //Aguarda a resposta
                    InputStream istream = socket.getInputStream();
                    InputStreamReader reader = new InputStreamReader(istream); 
                    BufferedReader br = new BufferedReader(reader); 
                    String msg = br.readLine();
                    this.nome = msg;
                    pai.replicaMensagem(msg + " entrou na sala.");
                }
                }catch(EOFException ie){
		}catch(IOException ie){
			ie.printStackTrace();
		}
		try{
                    
                    while(true){
                        //Aguarda a resposta
                        InputStream istream = socket.getInputStream();
                        InputStreamReader reader = new InputStreamReader(istream); 
                        BufferedReader br = new BufferedReader(reader); 
                        String msg = br.readLine();
                        if (msg.compareTo(("DELETARessaCONEXAOporfavor")) == 0)
                            this.fechaConexao();                                                                        
                        
                        if(msg.substring(0, 4).compareTo("/msg") == 0){                                                               
                            pai.replicaMensagem(msg);
                        }else{
                            pai.replicaMensagem(this.nome + " - " + msg);
                        }
                        
                    }
                }catch(Exception e){
                    pai.deletaThread(this);                
		}
	}
}