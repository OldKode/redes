/*
 * SimpleTalkGUI.java
 *
 * Created on 10/07/2010, 18:28:53
 */

import javax.swing.JFrame;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.swing.JOptionPane;


/*Thread que recebe mensagens do socket*/
class ThreadEscutVisual extends Thread {

    Socket s;
    SimpleTalkGUI t;

    ThreadEscutVisual(Socket socket, SimpleTalkGUI talkGUI) {
        s = socket;
        t = talkGUI;
    }

    public void run() {
        try {
            while (true) {
                //Aguarda a resposta
                InputStream istream = s.getInputStream();
                InputStreamReader reader = new InputStreamReader(istream);
                BufferedReader br = new BufferedReader(reader);
                String msg = br.readLine();
                t.setMsg(msg);

                t.addStrTextArea();
                Thread.sleep(200);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

public class SimpleTalkGUI extends javax.swing.JFrame {

    private JButton jButton1;
    private JButton jButton2;
    private JScrollPane jScrollPane1;
    private JTextArea jTextArea1;
    private JTextField jTextField1;
    private BorderLayout layout;
    private Socket socket;
    private OutputStream ostream;
    
    private String msg;    //msg precisa ser private para ser usada com invokeLater

    public SimpleTalkGUI(Socket s) {
        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        socket = s;

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                jTextArea1.setColumns(20);
                jTextArea1.setEditable(false);
                jTextArea1.setRows(5);
                jScrollPane1.setViewportView(jTextArea1);
                jButton1.setText("Enviar");
                jButton2.setText("Desconectar");
            }
        });

        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        layout = new BorderLayout(5, 5);
        getContentPane().setLayout(layout);
        add(jScrollPane1, BorderLayout.CENTER);
        add(jTextField1, BorderLayout.SOUTH);
        add(jButton1, BorderLayout.EAST);
        add(jButton2, BorderLayout.NORTH);
    }

    private void init(String nome) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                setTitle("Cliente");
            }
        });

        try {
            ostream = socket.getOutputStream();
            //Envia Mensagem via socket		    		
            PrintWriter pw = new PrintWriter(ostream, true);
            pw.println(nome);
        } catch (IOException e) {
            System.out.println("Não conseguiu pegar outputstream");
        }

    }

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {
        //Popula a area de texto com o conteundo do campo de texto
        setMsg(jTextField1.getText());
        //addStrTextArea();       

        //Envia Mensagem via socket		    		
        PrintWriter pw = new PrintWriter(ostream, true);
        pw.println(msg);

        //Limpa o campo de texto usando invokeLater
        //assim nao tem perigo de conflitarmos com a 
        //Thread do swing
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                jTextField1.setText(null);
            }
        });
    }

    //Necessário para que a threadEscuta possa acessar a variável msg
    public void setMsg(String message) {
        msg = message;
    }

    //Atualiza a area de texto com invokeLater
    public void addStrTextArea() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                jTextArea1.append(msg.trim() + "\n");
            }
        });
    }

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt){
        //A Fazer
        try{
            ostream = socket.getOutputStream();
            //Envia Mensagem via socket		    		
            PrintWriter pw = new PrintWriter(ostream, true);

            pw.println("DELETARessaCONEXAOporfavor");
        } catch (Exception e) {
            System.out.println("Falha ao conectar com servidor...");
        }
    }

    public static void main(String[] args) {
        try {
            //Cria o socket cliente, o jframe e a thread
            Socket socket = new Socket("127.0.0.1", 1234);
            String ipdoServidor = JOptionPane.showInputDialog("Informe o seu nome", "jooj");
            SimpleTalkGUI talkGUI = new SimpleTalkGUI(socket);
            ThreadEscutVisual tescuta = new ThreadEscutVisual(socket, talkGUI);

            //Configura a janela e torna ela visivel
            talkGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            talkGUI.setSize(300, 200); // set frame size
            talkGUI.init(ipdoServidor);
            talkGUI.setVisible(true);
            //Inicia a thread
            tescuta.start();
        } catch (Exception e) {
            System.out.println("Falha ao conectar com servidor...");
        }
    }
}
