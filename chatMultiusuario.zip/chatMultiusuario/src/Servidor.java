import java.io.*;
import java.net.*;
import java.util.*;

public class Servidor
{
	private ServerSocket ss;
	private int i = 0;
        private ArrayList<ServerThread> ServsT = new ArrayList();
        
	public Servidor(int port) throws IOException{
		ss = new ServerSocket ( port );
		System.out.println("Aguardando conexão de clientes...");
		while (true){
			Socket s = ss.accept();
                        i++;
			System.out.println( "Obteve conexao de " + s );
			ServsT.add(new ServerThread ( s , this, i));
                        
		}
	}
        
        public void replicaMensagem(String mens) throws IOException{
            
            String[] trat = mens.split(";");
            //if(mens.substring(0, 4).compareTo("/msg") == 0){                
            if(trat[0].compareTo("/msg") == 0){                
                validaNome(trat[1],trat[2]);                                    
            }else{
                System.out.println("todos");
                for (ServerThread servidor: ServsT) {            
                    servidor.enviaMensagem(mens);
                }
            }          
        }
        
        public void validaNome(String nome, String mensagem) throws IOException{
          for (ServerThread servidor: ServsT) {            
            if(servidor.validaNome(nome)){
                servidor.enviaMensagem(mensagem);
            }
              System.out.println("loop");            
          }          
        }
        
        public void deletaThread(ServerThread t){
            ServsT.remove(t);
        }
        
        public int ultimoConectado(){            
            return i;
        }
        
	static public void main ( String args[]) throws Exception {
		new Servidor(1234);
	}
}