/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joao.lslima1
 */
/*
 * SimpleTalkGUI.java
 *
 * Created on 10/07/2010, 18:28:53
 */

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;


/*Thread que recebe mensagens do socket*/
class ThreadEscuta extends Thread {
	Socket	 	s;
	Cliente 	t;
	ThreadEscuta(Socket socket, Cliente progCliente) {
                System.out.println("Iniciou Thread");
		s = socket;
		t = progCliente;
	}
	
	public void run() {
		try {
			while (true) {
				//Aguarda a resposta
				InputStream istream = s.getInputStream();
				InputStreamReader reader = new InputStreamReader(istream); 
				BufferedReader br = new BufferedReader(reader);  
                                
                                System.out.println("Aguardando algo");
				String msg = br.readLine();
                                System.out.println("Recebeu algo");
                                System.out.println(msg);
				
				//t.addStrTextArea(); 
				Thread.sleep(200);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

public class Cliente {
    
    private 	Socket  	socket;
    private	OutputStream 	ostream;
    private	String		msg;    //msg precisa ser private para ser usada com invokeLater
    
    public Cliente(Socket 	s) {        
	socket = s;
    }

    private void init() {    	
    	try {            
            ostream = socket.getOutputStream();
            //DataOutputStream o = new DataOutputStream(socket.getOutputStream());
        } catch (IOException e) {
            System.out.println("Não conseguiu pegar outputstream");
        }
        this.enviaMensagem();
    }
    
    public void enviaMensagem(){
        try{
            System.out.println("Aguardando numero");
            Scanner texto = new Scanner(System.in); 

            String msg = texto.nextLine();
            //Envia Mensagem via socket		    		
            PrintWriter pw = new PrintWriter(ostream, true); 
            pw.println(msg);
            if (msg != ""){
                this.enviaMensagem();
                msg = "";
            }
        }catch(Exception e){
            System.out.println("Conexão perdida com o servidor.");
        }
        
    }
    

    public static void main(String[] args) {
		try {
                    //Cria o socket cliente, o jframe e a thread
                    Socket socket = new Socket("127.0.0.1", 1234);
                    Cliente 	 talkGUI = new Cliente(socket);
                    ThreadEscuta tescuta = new ThreadEscuta(socket, talkGUI);
                    tescuta.start();
                    talkGUI.init();	
                    
                    
		} catch (Exception e) {
			System.out.println("Falha ao conectar com servidor...");
		}       
    }   
}
