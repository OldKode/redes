/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joao.lslima1
 */
/*
 * SimpleTalkGUI.java
 *
 * Created on 10/07/2010, 18:28:53
 */


import javax.swing.JFrame;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


/*Thread que recebe mensagens do socket*/
class ThreadEscuta extends Thread {
	SimpleTalkGUI 	t;
	ThreadEscuta(SimpleTalkGUI talkGUI) {
		t = talkGUI;
	}
	
	public void run() {
		try {
			while (true) {
				//Aguarda a resposta
                                InetAddress group = InetAddress.getByName(t.ipGeral);
                                MulticastSocket s = new MulticastSocket(t.socketChave);
                                s.joinGroup(group);
                                
                                byte[] buf = new byte[1000];
                                DatagramPacket recv = new DatagramPacket(buf, buf.length);
                                s.receive(recv); 
                                
                                String msg = new String(recv.getData()).trim();
                                
                                t.setMsg(msg);				
				t.addStrTextArea(); 
				Thread.sleep(200);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

public class SimpleTalkGUI extends javax.swing.JFrame {

    private 	JButton 		jButton1;
    private 	JButton 		jButton2;
    private 	JScrollPane 	jScrollPane1;
    private 	JTextArea 		jTextArea1;
    private 	JTextField 		jTextField1;
    private 	BorderLayout 	layout; 
    //private 	Socket  		socket;
    //private	OutputStream 	ostream;
    private	String			msg;    //msg precisa ser private para ser usada com invokeLater
    private     InetAddress group;
    private MulticastSocket working_socket;
    String ipGeral;
    int socketChave;
    //private     MulticastSocket s;
    
    
    
    public SimpleTalkGUI(String	ipChave, int socketChave) {        
	jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        this.ipGeral = ipChave;
        this.socketChave = socketChave;
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                jTextArea1.setColumns(20);
                jTextArea1.setEditable(false);
                jTextArea1.setRows(5);
                jScrollPane1.setViewportView(jTextArea1);
                jButton1.setText("Enviar");
                jButton2.setText("Desconectar");
            }
       });

        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                try {
                    jButton2MouseClicked(evt);
                } catch (IOException ex) {
                    Logger.getLogger(SimpleTalkGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
			
		layout = new BorderLayout( 5, 5 ); 
        getContentPane().setLayout(layout);
		add( jScrollPane1, BorderLayout.CENTER ); 
		add( jTextField1, BorderLayout.SOUTH ); 
		add( jButton1, BorderLayout.EAST ); 
		add( jButton2, BorderLayout.NORTH ); 		
    }

    private void init() throws IOException {
        group = InetAddress.getByName(this.ipGeral);
        working_socket = new MulticastSocket(this.socketChave);
        working_socket.joinGroup(group); 
        
    	SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				setTitle("Cliente");
			}
    	});
    }
    
    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {
        //Popula a area de texto com o conteundo do campo de texto
        setMsg(jTextField1.getText());
        //addStrTextArea();       

        //Envia Mensagem via socket		    		
        //PrintWriter pw = new PrintWriter(ostream, true); 
        //pw.println(msg);
        byte[] mens = new byte[100];
        mens = msg.getBytes();
        try {
            InetAddress address = InetAddress.getByName(this.ipGeral);
            DatagramPacket packet = new DatagramPacket(mens, mens.length, address, this.socketChave);
            working_socket.send(packet);
        } catch (Exception err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), null,
            JOptionPane.PLAIN_MESSAGE , null);
        }

        //Limpa o campo de texto usando invokeLater
        //assim nao tem perigo de conflitarmos com a 
        //Thread do swing
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                        jTextField1.setText(null);
                }
        });
    }
    
    //Necessário para que a threadEscuta possa acessar a variável msg
    public void setMsg(String message) {
    	msg = message;    	
    }

    //Atualiza a area de texto com invokeLater
    public void addStrTextArea() {        
        SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				jTextArea1.append(msg.trim() + "\n");
			}
		});
    }
        
    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) throws IOException {		
        working_socket.leaveGroup(this.group);
        working_socket.close();
    }
    
    public static void main(String[] args) {
		try {
			//Cria o socket cliente, o jframe e a thread
			String ipChave = "230.0.0.1";
                        int socketChave = 4446;
			SimpleTalkGUI 	talkGUI = new SimpleTalkGUI(ipChave, socketChave);
			ThreadEscuta 	tescuta = new ThreadEscuta(talkGUI);
			
			//Configura a janela e torna ela visivel
			talkGUI.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
			talkGUI.setSize( 300, 200 ); // set frame size
			talkGUI.init();
                        talkGUI.setVisible( true );
	        //Inicia a thread
			tescuta.start();
		} catch (Exception e) {
			System.out.println("Falha ao conectar com servidor...");
		}       
    }   
}
