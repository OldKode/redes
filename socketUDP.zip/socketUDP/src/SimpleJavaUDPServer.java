/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joao.lslima1
 */

import java.net.*;
import java.io.*;
public class SimpleJavaUDPServer {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket(1234); //Cria o socket
            String str;
            do {
                DatagramPacket requisicao = new DatagramPacket( new byte[100], 100 );
                socket.receive( requisicao );
                str = new String(requisicao.getData());
                System.out.println("Servidor recebeu: " + str.trim()
                    + " de " + requisicao.getAddress() + ", Porta = " 
                    + requisicao.getPort());
                socket.send( requisicao );
            } while ( !str.trim().equals("bye") ); //Enquanto a a msg for diferente de bye
                socket.close();
        } catch (Exception err) { //SocketException ou IOException
            System.err.println(err);
        }
    }
}