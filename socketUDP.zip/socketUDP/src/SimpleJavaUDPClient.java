/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joao.lslima1
 */
import java.net.*;
import java.io.*;
public class SimpleJavaUDPClient {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket(); //Cria o socket
            String str;
            do {
                byte[] msg = new byte[100];
                System.out.println("Digite uma mensagem: ");
                System.in.read(msg);
                DatagramPacket mensagem = new DatagramPacket(msg, msg.length,InetAddress.getLocalHost(), 1234);
                socket.send( mensagem );
                DatagramPacket resposta = new DatagramPacket( new byte[100], 100 );
                socket.receive( resposta );
                str = new String(resposta.getData()).trim();
                    System.out.println("Cliente recebeu: " + str + " do endereco = "
                    + resposta.getAddress() + ", porta = " + resposta.getPort());
            } while ( !str.equals("bye") ); //Enquanto a a msg for != de bye
            socket.close();
        } catch (Exception err) { //SocketException ou IOException
            System.err.println(err);
        }
    }
}