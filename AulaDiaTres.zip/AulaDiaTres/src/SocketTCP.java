

import java.net.*;
import java.io.*;
import java.util.Scanner;

/**
 *
 * @author joao.lslima1
 */
public class SocketTCP {
    Socket sock = null;
    public boolean ConectaTcp(String nome, int porta){
        try{
            Socket s = new Socket(nome, porta); 
            
        }catch(Exception err){
            //System.out.println(err);
            return false;
        }        
        return true;
    }
    
    public void ConectaServer(String nome, int porta){        
        Socket s;
        try{
            sock = new Socket(nome, porta); 
            System.out.println("Conseguiu conectar.");
        }catch(Exception err){
            System.out.println(err);           
        }                
    }
    
    public void enviaMensagem(String mens){
        try{
            InputStream i   = this.sock.getInputStream(); //Pega o stream de entrada do socket
            OutputStream o  = this.sock.getOutputStream(); //Pega o stream de saída do socket

            //DataOutputStream out = new DataOutputStream(o);

            String str;
            byte[] line = new byte[100];        
            //o.write(line); //escreva a mensagem no socket
            //out.writeChars(mens);
            o.write(mens.getBytes());
            i.read(line); //le a resposta do servidor
            str = new String(line);
            System.out.println(str.trim()); //mostra a resposta na tela       
        }catch(Exception err){
            System.out.println(err);           
        }  
    }
    
    public void enviaMensagem(){
        try{
            InputStream i   = this.sock.getInputStream(); //Pega o stream de entrada do socket
            OutputStream o  = this.sock.getOutputStream(); //Pega o stream de saída do socket


            String str;
            
            //chr a chr
            
            do {
                /*
                byte[] line = new byte[100];
                System.in.read(line); //le uma mensagem do usuário
                o.write(line); //escreva a mensagem no socket
                i.read(line); //le a resposta do servidor
                str = new String(line);
                System.out.println(str.trim()); //mostra a resposta na tela
                */
                //Envio de mensagem
                System.out.print("Cliente: ");
                Scanner sc = new Scanner(System.in);
                str = sc.nextLine();
                PrintWriter pw = new PrintWriter(o,true);
                pw.println(str);
                
                //Recebendo mensagem do servidor
                InputStreamReader reader = new InputStreamReader(i);
                BufferedReader br = new BufferedReader(reader);
                str = br.readLine();
                System.out.println("Servidor: "+str);               
            } while ( !str.trim().equals("bye") ); 
            
        }catch(Exception err){
            System.out.println(err);           
        }  
    }
    
    public void enviaComando(String comando){
        try{
            InputStream i   = this.sock.getInputStream(); //Pega o stream de entrada do socket
            OutputStream o  = this.sock.getOutputStream(); //Pega o stream de saída do socket
            //DataOutputStream out = new DataOutputStream(o);
            
            
            //System.in.read(comando); //le uma mensagem do usuário
            System.out.println("Enviando Mensagem...");
            //out.writeChars(comando); //escreva a mensagem no socket
            o.write(comando.getBytes());
            int b = 0;
            do {
               b = i.read(); //le a resposta do servidor
               if(b != -1)
                System.out.print((char)b);
            } while (b != -1); 
        }catch(Exception err){
            System.out.println(err);           
        }  
    }
}
