
import java.net.*;
import java.io.*;
import java.util.Scanner;
public class SimpleJavaServer {
    
    public static void main(String[] args) {
   
		try {
		       ServerSocket s = new ServerSocket(4567); //Cria o socket do servidor, porta 4567
		       System.out.println("Criou o socket");
                       String str;
		       while(true) {
                        System.out.println("Aguardando o cliente...");
			Socket c =s.accept(); //Fica bloqueado esperando uma solicita��o de conex�o
                        System.out.println("Aceito um cliente");
                        
		      	InputStream i = c.getInputStream();//Pega o stream de entrada do socket
		      	OutputStream o = c.getOutputStream();//Pega o stream de sa�da do socket
                        
                        
                        
                        
                        //chr a chr
                        
                        do {
                            /*
			         byte[] line = new byte[100];
			         i.read(line);                    //le a solicitacao do cliente 
			         o.write(line);	    //devolve a mesma mensagem para o cliente
			         str = new String(line);
				 System.out.println("Servidor recebeu = " + str);
                            */
                            //Pega mensagem enviada do cliente
                            InputStreamReader reader = new InputStreamReader(i);
                            BufferedReader br = new BufferedReader(reader);
                            str = br.readLine();
                            System.out.println("Cliente: "+str);                            
                            
                            if(str.equalsIgnoreCase("calcule")){
                                //Pega mensagem enviada do cliente                                         
                                PrintWriter pw = new PrintWriter(o, true);
                                pw.println("Digite o primeiro valor:");
                                int val1 = Integer.parseInt(br.readLine());                                
                                System.out.println("Cliente: "+val1);                                                                                                                              
                                pw.println("Primeiro valor " + val1);
                                                                
                                int val2 = Integer.parseInt(br.readLine());
                                System.out.println("Cliente: "+val2);                                
                                str = String.valueOf(val1 + val2);
                                pw.println("Resultado" + str);
                                //Scanner sc = new Scanner(System.in);
                                //str = sc.nextLine();
                                
                            }else{
                                
                                //Escreve mensagem
                                //Envio de mensagem
                                System.out.print("Servidor: ");
                                Scanner sc = new Scanner(System.in);
                                str = sc.nextLine();
                                
                                //Devolve mensagem
                                PrintWriter pw = new PrintWriter(o, true);
                                pw.println(str);
                            }
                            
		       	} while ( !str.trim().equals("bye") );  //Enquanto a a msg for diferente de bye
                        
                        
		      	c.close();
		        }
		}  catch (Exception err) {        //SocketException ou IOException
		       System.err.println(err);
		}

    }
}