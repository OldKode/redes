/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redes;

import java.io.*;
import java.util.ArrayList;
/**
 *
 * @author joao.lslima1
 */
public class save_load {
        
        public boolean Save(Jogador newPlayer){
            try {
                OutputStream out = new FileOutputStream("SavedGame.txt");
                ObjectOutputStream o = new ObjectOutputStream(out);           
                o.writeObject(newPlayer);          
                o.close();
                out.close();
                return true;
            } catch (Exception ex) {
                System.err.println(ex);
                return false;
            } 
        }
        
        public boolean SaveLista(ArrayList<Jogador> newPlayer){
            try {
                OutputStream out = new FileOutputStream("SavedGame.txt");
                ObjectOutputStream o = new ObjectOutputStream(out);           
                o.writeObject(newPlayer);          
                o.close();
                out.close();
                return true;
            } catch (Exception ex) {
                System.err.println(ex);
                return false;
            } 
        }
        
        
        public Jogador Carrega(){
            Jogador carregado;
            try {
                InputStream inp = new FileInputStream("SavedGame.txt");
                ObjectInputStream i = new ObjectInputStream(inp);
                carregado = (Jogador)i.readObject();
                
                i.close();
                inp.close(); 
                return carregado;

            } catch (Exception ex) {
                System.err.println(ex);
                return null;
            } 
        }
        
        public ArrayList<Jogador> CarregaLista(){
            ArrayList<Jogador> carregado;
            try {
                InputStream inp = new FileInputStream("SavedGame.txt");
                ObjectInputStream i = new ObjectInputStream(inp);
                carregado = (ArrayList)i.readObject();
                
                i.close();
                inp.close(); 
                return carregado;

            } catch (Exception ex) {
                System.err.println(ex);
                return null;
            } 
        }
           
}
