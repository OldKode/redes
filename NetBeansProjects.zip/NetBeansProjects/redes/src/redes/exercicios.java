package redes;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author joao.lslima1
 */
public class exercicios {
    public static void main(String[] args) {
        // segundo
        /*
        String esc = "Novo Recorde: Jogador 1";
        
        try {
            OutputStream out = new FileOutputStream("teste.txt");
            out.write(esc.getBytes());
            out.close();
        } catch (Exception ex) {
            System.err.println(ex);
        } 
        */
        
        //terceiro
        /*
        byte[] msgIn   = new byte[100];

        try{
            InputStream in = new FileInputStream("teste.txt");
            in.read(msgIn);
            System.out.println("Conteudo do arquivo: " + new String(msgIn));
        }catch( Exception ex){
            System.err.println(ex);
        } 
        */
        
        //quarto
        /*
        byte[] msgIn   = new byte[1];

        try{
            InputStream in = new FileInputStream("teste.txt");            
            int b = in.read();
            while(b != -1){
                System.out.print((char)b);
                b = in.read();
            }
            
        }catch( Exception ex){
            System.err.println(ex);
        } 
        */
        
        /*
        //Quinto
        int vida = 1;
        double som = 1.5;
        
        try {
            OutputStream out = new FileOutputStream("configuracao.txt");
            DataOutputStream o = new DataOutputStream(out);
            o.writeInt(vida);
            o.writeDouble(som);            
            o.close();
            out.close();
            
            InputStream inp = new FileInputStream("configuracao.txt");
            DataInputStream i = new DataInputStream(inp);
            vida    = i.readInt();
            som     = i.readDouble();
            
            System.out.println("Vida - " + vida + " Som - " + som);
            i.close();
            inp.close();            
            
        } catch (Exception ex) {
            System.err.println(ex);
        } 
        */
        
        /*
        //Sexto
        Jogador newPlayer = new Jogador("perdi",500,2);
        Jogador loadPlayer = new Jogador();
        
        save_load controle = new save_load();
        
        controle.Save(newPlayer);
        loadPlayer = controle.Carrega();
        System.out.println("Nome: " + loadPlayer.nome + " Pontos: " + loadPlayer.pontos + " Fase: " + loadPlayer.fase);
        */
        
         //Setimo
        
        ArrayList<Jogador> players = new ArrayList<Jogador>();
        players.add(new Jogador("João",500,2));
        players.add(new Jogador("Caio",500,2));
        players.add(new Jogador("Rarison",500,2));
        players.add(new Jogador("Julia",500,2));
        players.add(new Jogador("Aoki",500,2));
        players.add(new Jogador("Gabriel",500,2));
        players.add(new Jogador("Gabriel",500,2));
        players.add(new Jogador("Gabriel",500,2));
        players.add(new Jogador("Jonas",500,2));
        players.add(new Jogador("Vitor",500,2));
                
        ArrayList<Jogador> loadPlayer = new ArrayList<Jogador>();
        
        save_load controle = new save_load();
        
        controle.SaveLista(players);
                        
        loadPlayer = controle.CarregaLista();
        for(Jogador atual :loadPlayer){
            System.out.println("Nome: " + atual.nome + " Pontos: " + atual.pontos + " Fase: " + atual.fase);
        }
        
    }

}
