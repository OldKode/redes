package redes;
import java.io.Serializable;
/**
 *
 * @author joao.lslima1
 */
public class Jogador implements Serializable{
    String  nome    = "";
    int     pontos  = 0;
    int     fase    = 0;
    
    public Jogador(String nome, int pontos, int fase){
        this.nome = nome;
        this.pontos = pontos;
        this.fase = fase;
    }
    
    public Jogador(){
        this.nome = "";
        this.pontos = 0;
        this.fase = 0;
    }
}
