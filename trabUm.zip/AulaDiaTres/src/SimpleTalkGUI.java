import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class SimpleTalkGUI extends javax.swing.JFrame {

    /* A Fazer:
		Declarar o socket cliente ou servidor
     */	
    private Socket c;
    private JButton jButton1;
    private JButton jButton2;
    private JScrollPane jScrollPane1;
    private JTextArea jTextArea1;
    private JTextField jTextField1;
    private BorderLayout layout; 
    
    public SimpleTalkGUI() {        
	jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
	    
        jTextArea1.setColumns(20);
        jTextArea1.setEditable(false);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jButton1.setText("Enviar");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jButton2.setText("Desconectar");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
			
	layout = new BorderLayout( 5, 5 ); 
        getContentPane().setLayout(layout);
	add( jScrollPane1, BorderLayout.CENTER ); 
	add( jTextField1, BorderLayout.SOUTH ); 
	add( jButton1, BorderLayout.EAST ); 
	add( jButton2, BorderLayout.NORTH ); 		
    }

    public void init(){	
	/* A Fazer:
		Programa Cliente:
			1 - Criar um novo socket cliente	
	*/
        // Padrão
        String nome = "localhost";
        int porta = 4567;
        
        try{
            this.c = new Socket(nome, porta); 
            
        }catch(Exception err){
            addStrTextArea(String.valueOf(err));           
        }          
    }       
    
    //método que é chamado quando ocorre o clique do mouse no botão 1
    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {
	/* A Fazer:	
	     Cliente e Servidor 
	     1 - addStrTextArea(jTextField1.getText());       //Captura o texto do campo de texto e o insere na área de texto
	     2 - Envia mensagem jTextField1.getText() via socket
           3 - Aguarda Resposta do outro socket  (usando o método read do stream do socket)
	     4 - Incluir o texto recebido do socket na AreadeTexto com o método 
				addStrTextArea(mensagem);
			     onde mensagem é a string recebida via socket		
       */    
     try{
        InputStream i = this.c.getInputStream();//Pega o stream de entrada do socket
        OutputStream o = c.getOutputStream();//Pega o stream de sa�da do socket

        String str = "";               
        this.addStrTextArea("Cliente " + this.jTextField1.getText());
        
        //Devolve mensagem
        PrintWriter pw = new PrintWriter(o, true);
        pw.println(jTextField1.getText());
        this.jTextField1.setText("");
        
        //Aguarda resposta
        InputStreamReader reader = new InputStreamReader(i);
        BufferedReader br = new BufferedReader(reader);
        str = br.readLine();            

        //Envia para a caixa de texto.
        this.addStrTextArea("Cliente: "+str);
        
        
     }catch(Exception err){
         System.err.println(err);
     }
    }

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {
	/* A Fazer:	
	    Fecha o socket
	 */   
        try{
            this.c.close();
        }catch(Exception err){
            
        }
    }

    public void addStrTextArea(String str) {
        jTextArea1.append(str.trim() + "\n");
    }
    
    public static void main(String[] args) {
            SimpleTalkGUI talkGUI = new SimpleTalkGUI();
	    talkGUI.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	    talkGUI.setSize( 300, 200 ); // set frame size
            talkGUI.setVisible( true );
            talkGUI.init();
    }   
}